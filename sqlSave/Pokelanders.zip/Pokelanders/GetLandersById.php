<?php
    include("ConnectDb.php");

    $landerID = $_GET["ID"];

    $sql = "SELECT Name,Description FROM landers WHERE ID=" . $landerID;
    $result = $conn->query($sql);
    
    // Fetch only the first
    $row = $result->fetch_assoc();
    echo "Name=" . $row["Name"] . ";Description=" . $row["Description"];
?>